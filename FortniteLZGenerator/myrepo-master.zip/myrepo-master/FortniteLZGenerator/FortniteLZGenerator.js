const landingZones = ['Pleasant Park', 'Tilted Towers', 'Retail Row'];
const button = document.querySelector('button');
const result = document.querySelector('p.display');

function randomNumber(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

button.addEventListener('click', () {
    let n = randomNumber(landingZones.length);
    result.innerHTML = landingZones[n];
}


